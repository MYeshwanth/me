package com.cg.DAO;
import com.cg.util.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.PatientBean;

public class PatientDAO implements IPatientDAO
{
    Connection c=null;
    PreparedStatement pst=null;
    
	@Override
	public void addPatientDetails(PatientBean bean) throws Exception {
		// TODO Auto-generated method stub
		
		try {
			c=Commoncon.getCon();
			
			
			String sql="Insert into patient11 values (donorId_sequence.nextval,?,?,?,SYSDATE)";
			pst=c.prepareStatement("Insert into patient11 values (donorId_sequence.nextval,?,?,?,SYSDATE)");
			pst.setString(1,bean.getPatient_name());
			pst.setInt(2,bean.getAge());
			pst.setString(3,bean.getDescription());
			
			pst.executeUpdate();
			System.out.println("Inserted");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void getPatientDetails(int id) throws Exception {
		// TODO Auto-generated method stub
		c=Commoncon.getCon();
		
		
		
		pst=c.prepareStatement("select * from patient11 where patient_id="+id);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+rs.getInt(3)+rs.getString(4));
		}
	}

	
}
